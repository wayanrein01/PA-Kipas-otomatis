package org.d3ifcool.wayantiara.automaticfan.model

data class DevicesModel(
    var getDevicesName: String,
    var getDevicesHardwareAddress: String
)
